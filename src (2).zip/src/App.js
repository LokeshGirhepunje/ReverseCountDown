import ReverseCountDown from './CountDown/ReverseCountDown';
import './App.css';

function App() {
  return (
   <ReverseCountDown></ReverseCountDown>
  );
}

export default App;
