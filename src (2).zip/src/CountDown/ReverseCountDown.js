import { useEffect, useRef, useState } from "react";
import { Container,Row,Button } from "react-bootstrap";




function ReverseCountDown()
{
    let [times, setTimes] = useState(0)
   

    const id = useRef();


    const handleStartButton = () =>
    {
       
        id.current = setInterval(()=>{
                setTimes((prev)=>prev-1)
                console.log(times)
            },1000)
    }

   
    useEffect(()=>{
        return ()=>clearInterval(id.current);
    },[])

    return(<>
    <br></br>
    <br></br>
            <Container>
                <center><Row style={{border:"2px solid gray", borderRadius:"15px",width:"350px",height:"250px"}}>
                   <center>
                   <h1>CountDown</h1><br></br>
                        <h2>{times}</h2>
                      <br></br><br></br>
                    <Button variant="success" onClick={()=>handleStartButton()}>Start</Button>&nbsp;&nbsp;
                    <Button variant="success" onClick={()=>clearInterval(id.current)}>Pause</Button>&nbsp;&nbsp;
                    <Button variant="success"
                    onClick={()=>{
                        clearInterval(id.current)
                        setTimes(0)
                    }}
                    >Reset</Button>
                   </center>
                </Row></center>
            </Container>
    </>)
}
export default ReverseCountDown;