import CountDown from './CountDown/CountDown';
import './App.css';

function App() {
  return (
   <CountDown></CountDown>
  );
}

export default App;
